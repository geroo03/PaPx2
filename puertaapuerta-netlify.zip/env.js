window.SUPABASE_URL = "https://wzpyatgpunpbybqqstdf.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind6cHlhdGdwdW5wYnlicXFzdGRmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTU0NTMwMjcsImV4cCI6MjAzMTAyOTAyN30.8V3Yg_7_xXJ_Wv4vX_x-9X8VvX_x7_vX_x7_vX_x7_v";
// env.js - generated locally (DO NOT COMMIT)
window.SUPABASE_URL = "https://fmqlpgerqdiplnvjjarl.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZtcWxwZ2VycWRpcGxudmpqYXJsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5MTkwNTYsImV4cCI6MjA5MDQ5NTA1Nn0.r1X4NSX8t-v9EeJQ-eK9DVslIWkpo2_UCn-oRy6k--w";
