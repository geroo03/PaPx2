// Use the centralized config module to obtain the supabase client (anon/public key)
let sb = window.sb || null;
// If this script runs before the module that sets window.sb, try dynamic import as fallback.
// IMPORTANT: the path here is relative to this JS file (located in assets/js), so use './config.js'
(async function ensureClient(){
  if(!sb){
    try{
      // correct relative path: config.js sits in the same folder as this file
      const mod = await import('./config.js');
      sb = mod.supabase;
      window.sb = sb;
    }catch(e){
      console.warn('admin-acceso: no supabase client available yet or failed to import ./config.js', e);
      // keep sb null so callers can detect missing client
      sb = null;
      window.sb = null;
    }
  }
})();

// Admins are validated via Supabase user metadata: user.user_metadata.role === 'admin'

function showErr(m){const e=document.getElementById('err');e.textContent=m;e.style.display='block';document.getElementById('ok').style.display='none';}
function showOk(m){const e=document.getElementById('ok');e.textContent=m;e.style.display='block';document.getElementById('err').style.display='none';}

async function login(){
  const email=document.getElementById('email').value.trim();
  const pass=document.getElementById('pass').value;
  const btn=document.getElementById('btn');
  if(!email||!pass){showErr('Completá todos los campos.');return;}
  btn.disabled=true;btn.textContent='Verificando...';
  try{
    if(!sb || !sb.auth){
      throw {type:'no-client', message:'Supabase client no inicializado'};
    }
    const res = await sb.auth.signInWithPassword({email,password:pass});
    if(res.error){
      // Surface debug info
      const err = res.error;
      console.error('DEBUG SUPABASE: admin-acceso signInWithPassword error', err && err.message ? err.message : err);
      try { alert('Error de Supabase (admin login): ' + (err?.message || JSON.stringify(err))); } catch(e){}
      // Distinguish invalid credentials from other auth errors
      const msg = err?.message || '';
      if(err?.status === 400 || err?.status === 401 || /invalid|credential|incorrect/i.test(msg)){
        showErr('Email o contraseña incorrectos.');
      }else{
        showErr('Error de autenticación: ' + (msg || 'revisá la conexión.'));
      }
      btn.disabled=false; btn.textContent='Ingresar';
      return;
    }
    // Success - check role in returned session if available
    const session = res.data?.session || null;
    const user = session?.user || null;
    const role = user?.user_metadata?.role || null;
    if(role === 'admin'){
      showOk('✅ Acceso concedido. Redirigiendo...');
      setTimeout(()=>window.location.href='admin.html',1000);
      return;
    }else{
      // User authenticated but not admin: sign out to clear state and show error
      try{ await sb.auth.signOut(); }catch(_){/* ignore */}
      showErr('No tenés permisos de administrador.');
      btn.disabled=false; btn.textContent='Ingresar';
      return;
    }
  }catch(e){
  console.error('admin-acceso login error', e);
  try { alert('Error de Supabase (admin-acceso): ' + (e && e.message ? e.message : String(e))); } catch(_){}
    // Provide clearer feedback for connection/config issues vs auth failure
    if(e && (e.type === 'no-client' || e instanceof TypeError || /Failed to fetch|NetworkError/i.test(e?.message))){
      showErr('Error de conexión o configuración. Revisa SUPABASE_URL / ANON KEY y la red.');
    }else if(e && (e.status === 400 || e.status === 401 || /invalid|credential|incorrect/i.test(e?.message || ''))){
      showErr('Email o contraseña incorrectos.');
    }else{
      showErr('Error al autenticar. Por favor, intentá de nuevo.');
    }
    btn.disabled=false;btn.textContent='Ingresar';
  }
}

document.addEventListener('keydown',e=>{if(e.key==='Enter')login();});

// Check existing session if possible. Be defensive: sb may be null if config failed to load.
(async function checkSession(){
  try{
    if(!sb){
      // try to import config.js as a last resort
      const mod = await import('./config.js');
      sb = mod.supabase;
      window.sb = sb;
    }
    if(sb && sb.auth && typeof sb.auth.getSession === 'function'){
      const {data:{session}} = await sb.auth.getSession();
      const role = session?.user?.user_metadata?.role;
      if(session && role === 'admin'){
        window.location.href='admin.html';
      }
    }
  }catch(e){
    // non-fatal: just log so debug is easier
    console.warn('admin-acceso: session check failed or supabase client not available', e);
  }
})();