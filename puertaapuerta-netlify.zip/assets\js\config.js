import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// Configuración de Supabase
// Preferimos variables globales inyectadas en `window` (window.SUPABASE_URL / window.SUPABASE_ANON_KEY)
// para poder configurar el cliente desde cada HTML si es necesario.
export const SUPA_URL = (typeof window !== 'undefined' && window.SUPABASE_URL) ? window.SUPABASE_URL : 'TU_SUPABASE_URL_AQUI';
// IMPORTANT: Do NOT commit Supabase service_role keys. The frontend must use
// the public ANON key. The project contains a fallback anon key for local/dev
// convenience (replace via deploy pipeline in production).
export const SUPA_KEY = (typeof window !== 'undefined' && window.SUPABASE_ANON_KEY) ? window.SUPABASE_ANON_KEY : 'TU_SUPABASE_ANON_KEY_AQUI';

// Cliente instanciado (uses the anon/public key)
export const supabase = createClient(SUPA_URL, SUPA_KEY);

// Runtime configuration check: warn loudly in the browser console if the
// Supabase URL or ANON key are not set or still using a placeholder.
(function validateSupabaseConfig(){
	try{
		const isUrlMissing = !SUPA_URL || SUPA_URL.indexOf('supabase.co') === -1;
		const isKeyMissing = !SUPA_KEY || SUPA_KEY === 'TU_ANON_KEY_AQUI';

		// Expose a flag for runtime checks
		if (typeof window !== 'undefined') window.SUPABASE_CONFIG_OK = !(isUrlMissing || isKeyMissing);

		if (isUrlMissing || isKeyMissing) {
			console.error('⚠️ Error de Configuración: La URL o la ANON_KEY de Supabase no están configuradas correctamente. Revisá las variables de entorno o el archivo config.js');
			if (isUrlMissing) console.error(' - SUPABASE_URL parece inválida o no contiene "supabase.co":', SUPA_URL);
			if (isKeyMissing) console.error(' - SUPABASE_ANON_KEY está vacía o contiene el placeholder. Reemplazala en el deploy.');
		} else {
			// Helpful debug info (non-sensitive: only show key length)
			try{ console.info('Supabase config OK — URL:', SUPA_URL, 'ANON_KEY length:', (SUPA_KEY||'').length); }catch(e){}
		}
	}catch(e){/* no-op */}
})();
