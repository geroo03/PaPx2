// assets/js/main.js
import { supabase } from './config.js';
import { clienteAPI, comercioAPI, cadeteAPI } from './api.js';
import { sanitizeHTML, formatARS, navigateSeguro } from './ui.js';
import { state } from './state.js';

// ==========================================
// EXPOSICIÓN TEMPORAL PARA BACKWARD COMPATIBILITY
// ==========================================
// En los HTML actuales usan `sb` para acceder a Supabase. 
// Esto evita que rompan hasta refactorizar los .html nativos
window.sb = supabase;
window.supabase = supabase;
// Expose cadeteAPI for legacy non-module scripts (cadete.js uses it)
window.cadeteAPI = cadeteAPI;

// Utilidades UI accesibles desde el HTML global
window.sanitizeHTML = sanitizeHTML;
window.formatARS = formatARS;

// Inicializar estado guardado en LocalStorage (Offline Persistence)
state.init();
window.state = state; // EXPOSE STATE GLOBALLY FOR LEGACY SCRIPTS

// ==========================================
// ORQUESTADOR GLOBAL PARA EL HTML (Transición gradual)
// Conectamos las funciones a window para que los onclick="" del HTML funcionen
// NO INTENTAMOS ROMPER TODO AÚN, solo lo enlazamos al nuevo estado modular
// ==========================================

// Helper: build a resilient absolute URL from a project-relative path
export function buildUrl(relativePath){
  // Normalize
  if(!relativePath) relativePath = '';
  if(relativePath.startsWith('/')) relativePath = relativePath.slice(1);

  // If the request is for root or plain 'index.html', redirect to cliente/index.html
  if(relativePath === '' || relativePath === '.' || relativePath.toLowerCase() === 'index.html'){
    relativePath = 'cliente/index.html';
  }

  const base = window.location.origin + window.location.pathname.replace(/[^/]*$/, '');
  return new URL(relativePath, base).toString();
}
window.buildUrl = buildUrl;

// 1. Navegación Segura de Pantallas (reemplaza old `go` y repara el History API)


// 2. Carrito LocalStorage Wrapper




// ==========================================
// LISTENERS GLOBALES
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
  console.log('📦 Inicializando módulos V2 de Puerta a Puerta...');

  // Manejar la recuperación de sesión para Auth en toda la app
  const { data: { session } } = await supabase.auth.getSession();
  state.user = session?.user || null;

  // Listen for auth state changes (useful for OAuth redirects)
  try{
    supabase.auth.onAuthStateChange((event, sess) => {
      console.log('auth event', event);
      if (event === 'SIGNED_IN') {
        const role = sess?.user?.user_metadata?.role || sess?.user?.raw_user_meta_data?.role || null;
        if (role) {
          // Redirect user based on role; use buildUrl so redirects work even on subpaths
          if (role === 'admin') window.location.href = buildUrl('admin/admin.html');
          else if (role === 'embajador') window.location.href = buildUrl('embajador/dashboard.html');
          else if (role === 'comercio') window.location.href = buildUrl('comercio/comercio.html');
          else if (role === 'cadete') window.location.href = buildUrl('cadete/cadete.html');
          else if (role === 'usuario') window.location.href = buildUrl('cliente/index.html');
        } else {
          // If no role present, redirect to login page and show message
          console.warn('SIGNED_IN but no role metadata found for user. Redirecting to login.');
          window.location.href = buildUrl('cliente/login-usuario.html');
        }
      }
    });
  }catch(e){console.warn('Failed to attach auth state listener', e);} 
});


