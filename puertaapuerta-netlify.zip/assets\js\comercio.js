// La instanciación de supabase fue extraída a assets/js/config.js. Reemplazar esto en todo el frontend.
let cid=null,ab=true,prods=[],peds=[],delDef='app',epid=null,choices={};
let reporteActivo=null,chatInterval=null,tipoPromoSel='descuento';

import { ICONS } from './icons.js';

const VAPID_PUBLIC='BMOSombn5870MeH1ufWwYLEosTFqcDPuD5t-GtpWzQ33C8gEP0D9TC6IXvauq0qxDK13pUmtU0g8m-h25brELSM';
function urlBase64ToUint8Array(b){const p='='.repeat((4-b.length%4)%4);const base64=(b+p).replace(/-/g,'+').replace(/_/g,'/');const raw=window.atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)));}
async function inicializarNotificaciones(userId){try{if(!('serviceWorker'in navigator)||!('PushManager'in window))return;const permiso=await Notification.requestPermission();if(permiso!=='granted')return;const reg=await navigator.serviceWorker.register('../sw.js');await navigator.serviceWorker.ready;const old=await reg.pushManager.getSubscription();if(old)await old.unsubscribe();const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(VAPID_PUBLIC)});await sb.from('fcm_tokens').upsert({user_id:userId,token:JSON.stringify(sub),rol:'comercio'},{onConflict:'user_id'});console.log('Suscripcion guardada');}catch(err){console.error('Error notificaciones:',err);}}

function toast(m,d=2500){const t=document.getElementById('t');t.textContent=m;t.style.display='block';setTimeout(()=>t.style.display='none',d);}
function stab(tab){document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));document.querySelectorAll('.sec').forEach(s=>s.classList.remove('active'));document.getElementById('tab-'+tab).classList.add('active');document.getElementById('sec-'+tab).classList.add('active');}
function togAb(){ab=!ab;document.getElementById('tdot').className='tdot'+(ab?'':' off');document.getElementById('tlbl').textContent=ab?'Abierto':'Cerrado';toast(ab?'Local abierto':'Local cerrado');if(cid)sb.from('comercios').update({abierto_ahora:ab}).eq('id',cid);}
function sDel(el,t){document.querySelectorAll('.del-opt').forEach(o=>o.classList.remove('sel'));el.classList.add('sel');delDef=t;}
function sCad(pid,tipo){choices[pid]=tipo;document.querySelectorAll('.copt-'+pid).forEach(o=>o.classList.remove('sel'));document.getElementById('copt-'+pid+'-'+tipo).classList.add('sel');}

// ── PROMOCIONES ──
function selTipoPromo(tipo){
  tipoPromoSel=tipo;
  document.querySelectorAll('.tipo-btn').forEach(b=>b.classList.remove('sel'));
  document.getElementById('tbtn-'+tipo).classList.add('sel');
  document.getElementById('fg-porcentaje').style.display=tipo==='descuento'?'block':'none';
  document.getElementById('aviso-envio').style.display=tipo==='envio_gratis'?'block':'none';
}

function abrirOvPromo(){
  const sel=document.getElementById('pr-prod');
  sel.innerHTML='<option value="">Todo el menú</option>';
  prods.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.nombre;sel.appendChild(o);});
  document.getElementById('pr-fecha').min=new Date().toISOString().split('T')[0];
  document.getElementById('pr-fecha').value='';
  document.getElementById('pr-pct').value='';
  document.getElementById('pr-desc').value='';
  selTipoPromo('descuento');
  document.getElementById('ov-promo').classList.add('show');
}
function cerrarOvPromo(){document.getElementById('ov-promo').classList.remove('show');}

async function guardarPromo(){
  if(!cid){toast('Error: recarga la pagina');return;}
  if(tipoPromoSel==='descuento'){const pct=parseInt(document.getElementById('pr-pct').value);if(!pct||pct<1||pct>90){toast('Ingresa un porcentaje entre 1 y 90');return;}}
  const fecha=document.getElementById('pr-fecha').value;
  if(!fecha){toast('Elegi una fecha de vencimiento');return;}
  const promo={comercio_id:cid,tipo:tipoPromoSel,porcentaje:tipoPromoSel==='descuento'?parseInt(document.getElementById('pr-pct').value):null,producto_id:document.getElementById('pr-prod').value||null,descripcion:document.getElementById('pr-desc').value.trim()||null,fecha_fin:fecha,activa:true};
  console.log('Guardando promo con cid:', cid, promo);
  try{
    const{data,error}=await sb.from('promociones').insert([promo]).select().single();
    if(error){console.error('Error promo:',error);toast('Error: '+error.message);return;}
    cerrarOvPromo();toast('Promocion activada!');cargarPromociones();
  }catch(e){console.error('Excepcion promo:',e);toast('Error al guardar. Intenta de nuevo.');}
}

async function cargarPromociones(){
  const cont=document.getElementById('promos-list');
  cont.innerHTML='<div style="text-align:center;padding:30px;color:#888;font-size:13px;">Cargando...</div>';
  try{
    const{data}=await sb.from('promociones').select('*').eq('comercio_id',cid).order('created_at',{ascending:false});
    const promos=data||[];
  if(!promos.length){cont.innerHTML=`<div class="empty"><div class="big">${ICONS.fire}</div><p>No tenes promociones activas.<br>Crea una para atraer mas clientes.</p></div>`;return;}
    cont.innerHTML=promos.map(p=>{
      const vencida=p.fecha_fin&&new Date(p.fecha_fin)<new Date();
      const estado=!p.activa||vencida?'Vencida':'Activa';
      const estadoColor=estado==='Activa'?'#16A34A':'#9DA3AE';
      const estadoBg=estado==='Activa'?'#DCFCE7':'#F3F4F6';
      const tipoLabel=p.tipo==='descuento'?`${p.porcentaje}% de descuento`:'Envio gratis';
  const tipoIcon=p.tipo==='descuento'?'%':ICONS.scooter;
      const aplica='Todo el menu';
      const fechaFin=p.fecha_fin?new Date(p.fecha_fin).toLocaleDateString('es-AR'):'Sin limite';
      return`<div class="promo-card ${estado==='Activa'?'activa':''}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
          <div style="display:inline-flex;align-items:center;gap:6px;background:#FFF3E0;color:#E65100;font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;">${tipoIcon} ${tipoLabel}</div>
          <span style="font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;background:${estadoBg};color:${estadoColor};">${estado}</span>
        </div>
        <div style="font-size:14px;font-weight:700;color:#111;margin-bottom:4px;">${p.descripcion||tipoLabel}</div>
  <div style="font-size:11px;color:#888;">${ICONS.box} Aplica a: ${aplica} &nbsp;·&nbsp; ${ICONS.calendar} Hasta: ${fechaFin}</div>
        <div style="display:flex;gap:8px;margin-top:12px;">
          <button onclick="pausarPromo('${p.id}',${p.activa})" style="flex:1;padding:9px;border-radius:10px;border:1.5px solid #E0E0E0;background:#fff;font-size:12px;font-weight:700;color:#555;cursor:pointer;">${p.activa&&!vencida?'Pausar':'Reactivar'}</button>
          <button onclick="eliminarPromo('${p.id}')" style="flex:1;padding:9px;border-radius:10px;border:none;background:#FFEBEE;font-size:12px;font-weight:700;color:#B71C1C;cursor:pointer;">Eliminar</button>
        </div>
      </div>`;
    }).join('');
  }catch{cont.innerHTML=`<div class="empty"><div class="big">${ICONS.fire}</div><p>No tenes promociones todavia.</p></div>`;} 
}

async function pausarPromo(id,activa){
  try{await sb.from('promociones').update({activa:!activa}).eq('id',id);}catch{}
  toast(activa?'Promo pausada':'Promo reactivada');cargarPromociones();
}
async function eliminarPromo(id){
  if(!confirm('Eliminar esta promocion?'))return;
  try{await sb.from('promociones').delete().eq('id',id);}catch{}
  toast('Promocion eliminada');cargarPromociones();
}

// ── REPORTES ──
async function cargarReportes(){
  const cont=document.getElementById('reportes-list');
  cont.innerHTML='<div style="text-align:center;padding:30px;color:#888;font-size:13px;">Cargando...</div>';
  try{
    const{data}=await sb.from('reportes').select('*').eq('comercio_id',cid).eq('estado','pendiente').order('created_at',{ascending:false});
    const rep=data||[];const br=document.getElementById('br');br.style.display=rep.length?'inline-flex':'none';br.textContent=rep.length;
      if(!rep.length){cont.innerHTML=`<div style="display:flex;flex-direction:column;align-items:center;padding:48px 24px;text-align:center;"><div style="width:80px;height:80px;border-radius:50%;background:#E8F5E9;display:flex;align-items:center;justify-content:center;font-size:38px;margin-bottom:20px;">${ICONS.check}</div><div style="font-size:18px;font-weight:800;color:#111;margin-bottom:8px;">Todo en orden</div><div style="font-size:14px;color:#888;">No tenes reportes pendientes.</div></div>`;return;}
    const tipoLabel={'no-llegó':'No llego lo pedido','mal-estado':'Llego en mal estado','faltó-algo':'Falto algo','no-llegó-pedido':'No recibio el pedido'};
    cont.innerHTML=rep.map(r=>{const limite=r.limite_resolucion?new Date(r.limite_resolucion):null;const restante=limite?Math.max(0,limite-new Date()):0;const mins=Math.floor(restante/60000);const vencido=limite&&new Date()>limite;const color=vencido?'#DC2626':mins<=2?'#DC2626':'#FF6B35';
  return`<div style="background:#fff;border:1.5px solid ${vencido?'#FCA5A5':'#FECACA'};border-radius:14px;padding:14px;margin-bottom:12px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;"><div><div style="font-size:14px;font-weight:700;color:#111;">${ICONS.warn} ${tipoLabel[r.tipo]||r.tipo}</div><div style="font-size:11px;color:#888;margin-top:2px;">${new Date(r.created_at).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})} hs</div></div><div style="background:${vencido?'#FEE2E2':'#FFF8F6'};border-radius:20px;padding:5px 12px;font-size:13px;font-weight:700;color:${color};">${vencido?'Vencido':`${mins} min`}</div></div>${vencido?'<div style="background:#FEE2E2;border-radius:8px;padding:8px 12px;font-size:12px;color:#DC2626;margin-bottom:10px;">Tiempo vencido. El usuario recibe reembolso.</div>':'<div style="background:#FEF3C7;border-radius:8px;padding:8px 12px;font-size:12px;color:#92400E;margin-bottom:10px;">Habla con el usuario antes de que venza el tiempo.</div>'}<div style="display:flex;gap:8px;"><button onclick="abrirChat('${r.id}','${r.tipo}','${r.limite_resolucion||''}')" style="flex:1;background:#FF6B35;color:#fff;border:none;border-radius:10px;padding:11px;font-size:13px;font-weight:700;cursor:pointer;">${ICONS.chat} Abrir chat</button><button onclick="resolverReporte('${r.id}')" style="flex:1;background:#E8F5E9;color:#2E7D32;border:1.5px solid #A7F3D0;border-radius:10px;padding:11px;font-size:13px;font-weight:700;cursor:pointer;">${ICONS.check} Resolver</button></div></div>`;}).join('');
  }catch{cont.innerHTML='<div class="empty"><div class="big">✅</div><p>No tenes reportes activos.</p></div>';}
}
async function resolverReporte(id){try{await sb.from('reportes').update({estado:'resuelto'}).eq('id',id);}catch{}toast('Reporte resuelto');cargarReportes();}

// ── CHAT ──
async function abrirChat(reporteId,tipo,limiteStr){
  reporteActivo=reporteId;const tipoLabel={'no-llegó':'No llego','mal-estado':'Mal estado','faltó-algo':'Falto algo','no-llegó-pedido':'No recibio'};
  document.getElementById('chat-titulo').textContent=tipoLabel[tipo]||tipo;document.getElementById('chat-screen').classList.add('visible');await cargarMensajesChat(reporteId);
  if(chatInterval)clearInterval(chatInterval);let lastCount=0;
  chatInterval=setInterval(async()=>{try{const{data}=await sb.from('chat_reportes').select('*').eq('reporte_id',reporteId).order('created_at',{ascending:true});if(data&&data.length>lastCount){lastCount=data.length;const cont=document.getElementById('chat-msgs');if(!cont)return;cont.innerHTML=data.map(m=>{const hora=new Date(m.created_at||new Date()).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});if(m.de==='sistema')return`<div style="text-align:center;margin:8px 0;"><span style="background:#E0E0E0;color:#5C6270;font-size:11px;padding:4px 12px;border-radius:20px;">${m.texto}</span></div>`;if(m.de==='comercio')return`<div style="display:flex;justify-content:flex-end;margin:4px 0;"><div style="max-width:75%;background:#FF6B35;color:#fff;border-radius:16px 16px 4px 16px;padding:10px 14px;font-size:13px;">${m.texto}<div style="font-size:10px;opacity:.7;margin-top:4px;text-align:right;">${hora}</div></div></div>`;return`<div style="display:flex;justify-content:flex-start;margin:4px 0;"><div style="max-width:75%;background:#fff;color:#0D0D0D;border-radius:16px 16px 16px 4px;padding:10px 14px;font-size:13px;box-shadow:0 1px 4px rgba(0,0,0,.08);"><div style="font-size:10px;color:#9DA3AE;font-weight:700;margin-bottom:4px;">Usuario</div>${m.texto}<div style="font-size:10px;color:#9DA3AE;margin-top:4px;">${hora}</div></div></div>`;}).join('');cont.scrollTop=cont.scrollHeight;}}catch{}},3000);
  if(limiteStr&&limiteStr!=='null'&&limiteStr!==''){const limite=new Date(limiteStr);const cntI=setInterval(()=>{const r=Math.max(0,limite-new Date());const min=Math.floor(r/60000).toString().padStart(2,'0');const seg=Math.floor((r%60000)/1000).toString().padStart(2,'0');const chip=document.getElementById('chat-countdown');if(chip){chip.textContent=`${min}:${seg}`;chip.className='countdown-chip'+(r<120000?' urgente':'');}if(r<=0)clearInterval(cntI);},1000);}
}
async function cargarMensajesChat(reporteId){try{const{data}=await sb.from('chat_reportes').select('*').eq('reporte_id',reporteId).order('created_at',{ascending:true});const msgs=data||[];const cont=document.getElementById('chat-msgs');if(!cont)return;if(!msgs.length){cont.innerHTML='<div style="text-align:center;color:#9DA3AE;font-size:13px;padding:20px;">El usuario va a escribir aca. Responde rapido</div>';return;}cont.innerHTML=msgs.map(m=>{const hora=new Date(m.created_at||new Date()).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});if(m.de==='sistema')return`<div style="text-align:center;margin:8px 0;"><span style="background:#E0E0E0;color:#5C6270;font-size:11px;padding:4px 12px;border-radius:20px;">${m.texto}</span></div>`;if(m.de==='comercio')return`<div style="display:flex;justify-content:flex-end;margin:4px 0;"><div style="max-width:75%;background:#FF6B35;color:#fff;border-radius:16px 16px 4px 16px;padding:10px 14px;font-size:13px;line-height:1.4;">${m.texto}<div style="font-size:10px;opacity:.7;margin-top:4px;text-align:right;">${hora}</div></div></div>`;return`<div style="display:flex;justify-content:flex-start;margin:4px 0;"><div style="max-width:75%;background:#fff;color:#0D0D0D;border-radius:16px 16px 16px 4px;padding:10px 14px;font-size:13px;line-height:1.4;box-shadow:0 1px 4px rgba(0,0,0,.08);"><div style="font-size:10px;color:#9DA3AE;font-weight:700;margin-bottom:4px;">Usuario</div>${m.texto}<div style="font-size:10px;color:#9DA3AE;margin-top:4px;">${hora}</div></div></div>`;}).join('');cont.scrollTop=cont.scrollHeight;}catch{}}
async function enviarRespuesta(){const input=document.getElementById('chat-resp');if(!input||!input.value.trim())return;const texto=input.value.trim();input.value='';const hora=new Date().toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});const cont=document.getElementById('chat-msgs');if(cont){const div=document.createElement('div');div.style.cssText='display:flex;justify-content:flex-end;margin:4px 0;';div.innerHTML=`<div style="max-width:75%;background:#FF6B35;color:#fff;border-radius:16px 16px 4px 16px;padding:10px 14px;font-size:13px;line-height:1.4;">${texto}<div style="font-size:10px;opacity:.7;margin-top:4px;text-align:right;">${hora}</div></div>`;cont.appendChild(div);cont.scrollTop=cont.scrollHeight;}try{await sb.from('chat_reportes').insert([{reporte_id:reporteActivo,de:'comercio',texto}]);}catch{}}
function cerrarChat(){document.getElementById('chat-screen').classList.remove('visible');if(chatInterval)clearInterval(chatInterval);reporteActivo=null;}

// ── INIT ──
async function init(){
  try{const{data:{session}}=await sb.auth.getSession();const userId=session?.user?.id;let query=sb.from('comercios').select('*');if(userId)query=query.eq('usuario_id',userId);const{data}=await query.limit(1).single();
  if(data){cid=data.id;document.getElementById('cnombre').textContent=data.nombre;setTimeout(checkMPConectado,1000);document.getElementById('cn').value=data.nombre||'';document.getElementById('cc').value=data.categoria||'comida';document.getElementById('cd').value=data.direccion||'';document.getElementById('ct').value=data.telefono||'';document.getElementById('ce').value=data.precio_envio_propio||800;document.getElementById('cr').value=data.radio_entrega_km||3;document.getElementById('s-rat').textContent=data.rating||'5.0';ab=data.abierto_ahora!==false;document.getElementById('tdot').className='tdot'+(ab?'':' off');document.getElementById('tlbl').textContent=ab?'Abierto':'Cerrado';}
  // Initialize default delivery UI if comercio has a tipo_delivery
  try{
    if(data && data.tipo_delivery){ delDef = data.tipo_delivery; document.querySelectorAll('#delivery-default-controls .del-opt').forEach(b=>b.classList.remove('sel')); const btn = Array.from(document.querySelectorAll('#delivery-default-controls .del-opt')).find(b=>b.textContent.trim().toLowerCase().includes(delDef==='app'?'pap':'mi cadete')); if(btn)btn.classList.add('sel'); }
  }catch(e){/* ignore */}
  if(userId)inicializarNotificaciones(userId);}catch{}
  await cargarProds();await cargarPeds();verificarReportesPendientes();
}

async function verificarReportesPendientes(){try{const{data}=await sb.from('reportes').select('id').eq('comercio_id',cid).eq('estado','pendiente');const n=data?.length||0;const br=document.getElementById('br');if(n>0){br.style.display='inline-flex';br.textContent=n;toast(`Tenes ${n} reporte${n>1?'s':''} pendiente${n>1?'s':''}. Responde rapido!`,5000);}}catch{}}
async function cargarProds(){try{const{data}=await sb.from('productos').select('*').eq('comercio_id',cid).order('categoria');prods=data||[];}catch{prods=[];}renderProds();}
async function cargarPeds(){try{const{data}=await sb.from('pedidos').select('*').eq('comercio_id',cid).order('created_at',{ascending:false}).limit(20);peds=data||[];}catch{peds=[];}renderPeds();stats();}

function renderPeds(){
  const nv=peds.filter(p=>p.estado==='nuevo').length;const bn=document.getElementById('bn');bn.style.display=nv>0?'inline-flex':'none';bn.textContent=nv;
  if(!peds.length){document.getElementById('pc').innerHTML=`<div class="empty"><div class="big">${ICONS.confetti}</div><p>Sin pedidos pendientes.</p></div>`;return;}
  const eL={nuevo:'Nuevo',preparando:'Preparando',en_camino:'En camino',entregado:'Entregado',cancelado:'Cancelado'};const eC={nuevo:'ep-nuevo',preparando:'ep-prep',en_camino:'ep-cam',entregado:'ep-done',cancelado:'ep-can'};
  document.getElementById('pc').innerHTML=peds.map(p=>{const its=(Array.isArray(p.items)?p.items:[]).map(i=>`${i.qty||1}x ${i.nombre}`).join(', ');const hr=new Date(p.created_at).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'});const ch=choices[p.id]||'propio';
  let cadSec='';if(p.estado==='nuevo'){cadSec=`<div style="margin-bottom:12px;"><div class="choice-label">Quien hace el delivery?</div><div class="choice-opts"><div class="c-opt copt-${p.id} ${ch==='propio'?'sel':''}" id="copt-${p.id}-propio" onclick="sCad('${p.id}','propio')"><div class="co-icon">🏍️</div><div class="co-lbl">Mi cadete</div><div class="co-sub">Vos coordinas</div></div><div class="c-opt copt-${p.id} ${ch==='app'?'sel':''}" id="copt-${p.id}-app" onclick="sCad('${p.id}','app')"><div class="co-icon">📱</div><div class="co-lbl">Red P a P</div><div class="co-sub">App asigna uno</div></div></div></div>`;}
  let acts='';if(p.estado==='nuevo'){const waMsg=encodeURIComponent(`Puerta a Puerta\nPedido #${p.numero||'-'}\n${(Array.isArray(p.items)?p.items:[]).map(i=>`- ${i.qty||1}x ${i.nombre}`).join('\n')}\nTotal: $${Number(p.total||0).toLocaleString('es-AR')}`);acts=`<button class="btn btn-o" onclick="acept('${p.id}')">Aceptar</button><button class="btn btn-r" onclick="chEst('${p.id}','cancelado')">Rechazar</button><a href="https://wa.me/?text=${waMsg}" target="_blank" class="btn" style="background:#25D366;color:#fff;text-decoration:none;display:flex;align-items:center;justify-content:center;">WA</a>`;}
  else if(p.estado==='preparando')acts=`<button class="btn-full btn-o" onclick="chEst('${p.id}','en_camino')">Listo para enviar</button>`;
  else if(p.estado==='en_camino')acts=`<button class="btn-full" style="background:#f0f0f0;color:#555;width:100%;padding:12px;border-radius:10px;border:none;font-size:13px;font-weight:700;cursor:pointer;" onclick="chEst('${p.id}','entregado')">Marcar entregado</button>`;
  return`<div class="ped-card ${p.estado==='nuevo'?'nuevo':''}"><div class="ped-head"><div><div class="ped-num">Pedido #${p.numero||'-'}</div><div class="ped-time">${hr} hs</div></div><span class="ep ${eC[p.estado]||'ep-nuevo'}">${eL[p.estado]||'Nuevo'}</span></div><div class="ped-items">${its}</div><div class="ped-total">Total: $${Number(p.total||0).toLocaleString('es-AR')}</div>${cadSec}${acts?`<div class="ped-acts">${acts}</div>`:''}</div>`;}).join('');
}
async function acept(id){const ch=choices[id]||'propio';const p=peds.find(x=>x.id===id);if(p){p.estado='preparando';p.tipo_delivery=ch;}try{await sb.from('pedidos').update({estado:'preparando',tipo_delivery:ch}).eq('id',id);}catch{}renderPeds();toast(ch==='app'?'Pedido aceptado - Buscando cadete...':'Pedido aceptado');}
async function chEst(id,est){const msgs={en_camino:'Listo para enviar',entregado:'Entregado',cancelado:'Rechazado'};const p=peds.find(x=>x.id===id);if(p)p.estado=est;try{await sb.from('pedidos').update({estado:est}).eq('id',id);}catch{}renderPeds();toast(msgs[est]||'Actualizado');}

function renderProds(){if(!prods.length){document.getElementById('prc').innerHTML=`<div class="empty"><div class="big">${ICONS.plate}</div><p>Carga tus productos.</p></div>`;return;}const cats=[...new Set(prods.map(p=>p.categoria))];document.getElementById('prc').innerHTML=cats.map(cat=>`<div class="cat-lbl">${cat}</div>${prods.filter(p=>p.categoria===cat).map(p=>`<div class="prod-row"><div><div class="p-name">${p.nombre}</div><div class="p-cat">${p.descripcion||''}</div></div><div style="display:flex;align-items:center;"><div class="p-price">$${Number(p.precio).toLocaleString('es-AR')}</div><button class="p-tog ${p.disponible?'on':''}" onclick="togP('${p.id}',this)"></button></div></div>`).join('')}`).join('');}
async function togP(id,btn){btn.classList.toggle('on');const d=btn.classList.contains('on');const p=prods.find(x=>x.id===id);if(p)p.disponible=d;try{await sb.from('productos').update({disponible:d}).eq('id',id);}catch{}toast(d?'Disponible':'Pausado');}
function stats(){const h=peds.filter(p=>{const d=new Date(p.created_at),n=new Date();return d.getDate()===n.getDate()&&d.getMonth()===n.getMonth();});document.getElementById('s-hoy').textContent=h.length;const tot=peds.reduce((s,p)=>s+Number(p.total||0),0);document.getElementById('s-sem').textContent=tot>0?`$${Math.round(tot/1000)}K`:'$0';}

function abrirF(){epid=null;document.getElementById('ft').textContent='Agregar producto';document.getElementById('pn').value='';document.getElementById('pd').value='';document.getElementById('pp').value='';document.getElementById('pcat').value='';document.getElementById('ov').classList.add('show');}
function cerrarF(){document.getElementById('ov').classList.remove('show');}
async function guardarProd(){const nom=document.getElementById('pn').value.trim();const pre=parseFloat(document.getElementById('pp').value);if(!nom||!pre){toast('Completa nombre y precio');return;}const p={nombre:nom,descripcion:document.getElementById('pd').value.trim(),precio:pre,categoria:document.getElementById('pcat').value.trim()||'General',disponible:true,comercio_id:cid};try{if(epid)await sb.from('productos').update(p).eq('id',epid);else await sb.from('productos').insert([p]);}catch{}cerrarF();await cargarProds();toast('Producto guardado');}
async function guardarCfg(){const cfg={nombre:document.getElementById('cn').value.trim(),categoria:document.getElementById('cc').value,direccion:document.getElementById('cd').value.trim(),telefono:document.getElementById('ct').value.trim(),precio_envio_propio:parseFloat(document.getElementById('ce').value)||800,radio_entrega_km:parseFloat(document.getElementById('cr').value)||3,tipo_delivery:delDef};if(cfg.nombre)document.getElementById('cnombre').textContent=cfg.nombre;try{if(cid)await sb.from('comercios').update(cfg).eq('id',cid);}catch{}toast('Configuracion guardada');}

function selMetodoCobro(metodo){const esMp=metodo==='mp';document.getElementById('cobro-mp').style.borderColor=esMp?'#FF6B35':'#E0E0E0';document.getElementById('cobro-mp').style.background=esMp?'#FFF8F6':'#fff';document.getElementById('dot-mp').style.background=esMp?'#FF6B35':'#fff';document.getElementById('dot-mp').style.borderColor=esMp?'#FF6B35':'#E0E0E0';document.getElementById('cobro-transferencia').style.borderColor=!esMp?'#FF6B35':'#E0E0E0';document.getElementById('cobro-transferencia').style.background=!esMp?'#FFF8F6':'#fff';document.getElementById('dot-transferencia').style.background=!esMp?'#FF6B35':'#fff';document.getElementById('dot-transferencia').style.borderColor=!esMp?'#FF6B35':'#E0E0E0';document.getElementById('mp-status-box').style.display=esMp?'block':'none';document.getElementById('cbu-box').style.display=!esMp?'block':'none';}
async function guardarCBU(){const cbu=document.getElementById('cbu-input').value.trim();const banco=document.getElementById('banco-input').value.trim();if(!cbu){toast('Ingresa tu CBU o alias');return;}try{await sb.from('comercios').update({cbu_alias:cbu,banco}).eq('id',cid);toast('Datos bancarios guardados');}catch{toast('Guardado localmente');}}
function conectarMP(){const CLIENT_ID='3886989011728021';const REDIRECT_URI=encodeURIComponent('https://puertaapuerta.vercel.app/oauth-callback.html');const STATE=cid||'comercio';window.location.href=`https://auth.mercadopago.com.ar/authorization?client_id=${CLIENT_ID}&response_type=code&platform_id=mp&redirect_uri=${REDIRECT_URI}&state=${STATE}`;}
async function checkMPConectado(){if(!cid)return;try{const{data}=await sb.from('comercios').select('mp_conectado').eq('id',cid).single();if(data?.mp_conectado){document.getElementById('mp-no-conectado').style.display='none';document.getElementById('mp-conectado').style.display='flex';}}catch{}}

setInterval(cargarPeds,30000);setInterval(verificarReportesPendientes,5000);

// ── IA ──
let iaHistorial=[],iaIniciado=false;
async function iniciarAsistenteIA(){if(iaIniciado)return;iaIniciado=true;agregarMsgIA('bot','Hola! Soy tu asistente de negocio.\n\nPuedo ayudarte con:\n- Como mejorar tu rating y ventas\n- Que hacer con reportes\n- Que promociones funcionan mejor\n- Configuracion de pagos\n\nEn que te ayudo?');await cargarAlertasIA();}
async function cargarAlertasIA(){try{const{data:reps}=await sb.from('reportes').select('tipo').eq('comercio_id',cid).gte('created_at',new Date(Date.now()-7*24*60*60*1000).toISOString());const cont=document.getElementById('ia-alertas');if(!cont||!reps||!reps.length)return;const conteo={};reps.forEach(r=>conteo[r.tipo]=(conteo[r.tipo]||0)+1);const alertas=Object.entries(conteo).filter(([,n])=>n>=2);if(!alertas.length)return;cont.innerHTML=alertas.map(([tipo,n])=>`<div style="background:#FEF3C7;border-radius:12px;padding:12px 14px;margin-bottom:8px;display:flex;gap:10px;align-items:flex-start;"><span>⚠️</span><div><div style="font-size:13px;font-weight:700;color:#92400E;">Alerta: ${tipo}</div><div style="font-size:12px;color:#92400E;margin-top:2px;">Tuviste ${n} reportes esta semana.</div><button onclick="preguntaRapidaIA('Tuve ${n} reportes de ${tipo} esta semana, que hago?')" style="background:#FF6B35;color:#fff;border:none;border-radius:8px;padding:5px 10px;font-size:11px;font-weight:700;cursor:pointer;margin-top:6px;">Ver consejos</button></div></div>`).join('');}catch{}}
function agregarMsgIA(de,texto){const cont=document.getElementById('ia-msgs');if(!cont)return;const esBot=de==='bot';const textoHtml=texto.replace(/\n/g,'<br>');const div=document.createElement('div');div.style.cssText=`display:flex;justify-content:${esBot?'flex-start':'flex-end'};`;if(esBot){div.innerHTML=`<div style="max-width:85%;background:#fff;color:#111;border-radius:4px 14px 14px 14px;padding:10px 14px;font-size:13px;line-height:1.6;box-shadow:0 1px 3px rgba(0,0,0,.08);">${textoHtml}</div>`;}else{div.innerHTML=`<div style="max-width:85%;background:#FF6B35;color:#fff;border-radius:14px 14px 4px 14px;padding:10px 14px;font-size:13px;line-height:1.5;">${textoHtml}</div>`;}cont.appendChild(div);cont.scrollTop=cont.scrollHeight;}
function preguntaRapidaIA(p){const input=document.getElementById('ia-input');if(input){input.value=p;enviarIA();}}
async function enviarIA(){const input=document.getElementById('ia-input');const btn=document.getElementById('ia-btn');if(!input||!input.value.trim())return;const texto=input.value.trim();input.value='';btn.disabled=true;agregarMsgIA('usuario',texto);iaHistorial.push({role:'user',content:texto});const cont=document.getElementById('ia-msgs');const typing=document.createElement('div');typing.id='ia-typing';typing.style.cssText='display:flex;justify-content:flex-start;';typing.innerHTML=`<div style="background:#fff;border-radius:4px 14px 14px 14px;padding:10px 16px;box-shadow:0 1px 3px rgba(0,0,0,.08);"><div style="display:flex;gap:4px;height:16px;align-items:center;"><div style="width:6px;height:6px;border-radius:50%;background:#ccc;animation:bounce 1.2s infinite;"></div><div style="width:6px;height:6px;border-radius:50%;background:#ccc;animation:bounce 1.2s .2s infinite;"></div><div style="width:6px;height:6px;border-radius:50%;background:#ccc;animation:bounce 1.2s .4s infinite;"></div></div></div>`;if(cont){cont.appendChild(typing);cont.scrollTop=cont.scrollHeight;}try{const res=await fetch('https://fmqlpgerqdiplnvjjarl.supabase.co/functions/v1/asistente',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+(window.SUPABASE_ANON_KEY||'')},body:JSON.stringify({messages:iaHistorial,rol:'comercio'})});const data=await res.json();const respuesta=data.respuesta||'No pude procesar tu consulta.';document.getElementById('ia-typing')?.remove();agregarMsgIA('bot',respuesta);iaHistorial.push({role:'assistant',content:respuesta});}catch{document.getElementById('ia-typing')?.remove();agregarMsgIA('bot','Error de conexion. Intenta de nuevo.');}btn.disabled=false;}
const iaBounce=document.createElement('style');iaBounce.textContent=`@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}`;document.head.appendChild(iaBounce);

function iniciarRealtime(){
  try{
    // Unsubscribe existing channels if any
    try{ window._comercio_pedidos_channel?.unsubscribe(); }catch(e){}
    try{ window._comercio_reportes_channel?.unsubscribe(); }catch(e){}

    // If we have a comercio id, subscribe only to relevant rows server-side via filter
    if(cid){
      window._comercio_pedidos_channel = sb.channel('pedidos-nuevos')
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'pedidos',filter:`comercio_id=eq.${cid}`},(payload)=>{ sonarNotificacion(); toast('Nuevo pedido!',4000); cargarPeds(); })
        .on('postgres_changes',{event:'UPDATE',schema:'public',table:'pedidos',filter:`comercio_id=eq.${cid}`},(payload)=>{ cargarPeds(); })
        .subscribe();

      window._comercio_reportes_channel = sb.channel('reportes-nuevos')
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'reportes',filter:`comercio_id=eq.${cid}`},(payload)=>{ sonarNotificacion(); toast('Nuevo reporte!',5000); verificarReportesPendientes(); })
        .subscribe();
    } else {
      // Fallback: subscribe to table-wide events but filter client-side
      window._comercio_pedidos_channel = sb.channel('pedidos-nuevos')
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'pedidos'},(payload)=>{ if(payload.new?.comercio_id==cid||!cid){ sonarNotificacion(); toast('Nuevo pedido!',4000); cargarPeds(); } })
        .on('postgres_changes',{event:'UPDATE',schema:'public',table:'pedidos'},(payload)=>{ if(payload.new?.comercio_id==cid||!cid) cargarPeds(); })
        .subscribe();

      window._comercio_reportes_channel = sb.channel('reportes-nuevos')
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'reportes'},(payload)=>{ if(payload.new?.comercio_id==cid||!cid){ sonarNotificacion(); toast('Nuevo reporte!',5000); verificarReportesPendientes(); } })
        .subscribe();
    }

    // Ensure channels are cleaned up on page unload to avoid dangling subscriptions
    if(!window._comercio_unload_attached){
      window.addEventListener('beforeunload', ()=>{
        try{ window._comercio_pedidos_channel?.unsubscribe(); }catch(e){}
        try{ window._comercio_reportes_channel?.unsubscribe(); }catch(e){}
      });
      window._comercio_unload_attached = true;
    }
  }catch(e){ console.error('iniciarRealtime error', e); }
}
function sonarNotificacion(){try{const ctx=new(window.AudioContext||window.webkitAudioContext)();[523,659,784].forEach((freq,i)=>{const osc=ctx.createOscillator();const gain=ctx.createGain();osc.connect(gain);gain.connect(ctx.destination);osc.frequency.value=freq;osc.type='sine';gain.gain.setValueAtTime(0.3,ctx.currentTime+i*.15);gain.gain.exponentialRampToValueAtTime(0.01,ctx.currentTime+i*.15+.2);osc.start(ctx.currentTime+i*.15);osc.stop(ctx.currentTime+i*.15+.2);});}catch{}}

// Strict, idempotent guard: only allow users with role === 'comercio'
;(async function guardComercio(){
  if(window._comercio_redirecting) return;
  try{
    const { data: { session } } = await sb.auth.getSession();
    const user = session?.user || null;
    const role = user?.user_metadata?.role || user?.raw_user_meta_data?.role || null;
    if(!session || role !== 'comercio'){
      // Not authorized for comercio UI: sign out and replace location to avoid adding history entries
      window._comercio_redirecting = true;
      try{ await sb.auth.signOut(); }catch(e){}
      try{ alert('Acceso restringido: Panel de Comercio'); }catch(e){}
      // Redirect to the comercio local login page (defensive replace to avoid history entry)
      window.location.replace('login.html');
      return;
    }
    // authorized
    init();
  }catch(e){
    console.warn('comercio guard check failed', e);
    if(!window._comercio_redirecting){
      window._comercio_redirecting = true;
      try{ await sb.auth.signOut(); }catch(e){}
      // Defensive redirect to local login within comercio folder
      window.location.replace('login.html');
    }
  }
})();
let deferredPrompt=null;window.addEventListener('beforeinstallprompt',(e)=>{e.preventDefault();deferredPrompt=e;});
iniciarRealtime();